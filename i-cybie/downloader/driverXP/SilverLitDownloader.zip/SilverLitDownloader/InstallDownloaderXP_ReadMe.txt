Install DownloaderXP ReadMe
This will work only on WindowsXP, including on a virtual machine.

Installation:

First click on AllowIO.exe to run it. It will automatically install the PortTalk driver, if an error prevents that installation just copy the file, porttalk.sys to your Windows/System32 directory. The source code for the version of PortTalk used here is available at:

http://cartheur.com

The command must be executed on the command-line. For convenience, use the Command Prompt shortcut to open a command window at his directory. Navigate to or click DownloaderXP.cmd to run the program. Once your Downloader is running, according to the instructions from SilverLit, you can copy a standard or enhaced behavior or personality to your cartrdige that you have downloaded from:

http://cartheur.com

The complete AllowIO/PortTalk archive is included if you need it. It contains source code and applicable headers and examples to include AllowIO in your own applications.

Setting your Bios:

Set your parallel port to the simplest function first, to see what works best for your system - Bi-Directional provides the best results.

For WindowsXP:

1. Right-click on My Computer and select Properties,

2. Select Hardware and then click Device Manager,

3. Click the + next to Ports in the list of hardware,

4. Right-Click Printer Port, and select Properties,

5. Click Port Settings, and make sure Use Any Interrupt Assigned to a Port is selected,

6. Click Resources and note the IO range and IRQ, these should be 0378-037F and an IRQ of 07. The 0378-037F range is suggested.


Now you are ready to download your own custom programs to iCybie's memory cards.

-----------

Downloader.exe is the property of Silverlit, and disributed here for non-commercial use and is copyrighted by Silverlit: http://www.silverlit.com/news.html


AllowIO/PortTalk is freely available, and the latest version can be downloaded at: http://www.beyondlogic.org/porttalk/porttalk.htm


