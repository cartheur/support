iCybie Action Viewer - version 2.01

Instructions

Download icview2.zip and unzip it to your computer. Run the icview2.exe. It needs the ICYBIE2.BRW and VIRTAIBO2.DLL files to be in the same directory. For convenience, keep all files in this directory.

Select an "action" from the list and press the "Play Action" button (or just double-click on the action name. Watch the action be performed on the 3D Virtual AIBO. You can resize the window, or grab 3D Virtual AIBO to move or rotate him. Hold down the shift key to rotate him.

The performance playback has a low granularity and is only for a general indication of what limbs move and perhaps what sounds are played. Run on a Super-iCybie to see the real actions in action.
Other tips: press and hold the BACKSPACE key to stop playing the current action, especially if a long action - like the Life-of-iCybie or iCybie the great.

This simulator gives an approximation of the iCybie motion.

It is only intended to give you a rough indication of what the actions look like.


========================================================================
History:

Version 2.01 - performs actions based on the Walkup8A cartridge
    Repeated actions not supported
    rough names for some actions

Version 1.01 - performs skits and other actions based on the OLDROM

